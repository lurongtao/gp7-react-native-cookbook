import App from './build/App'
export default App