import list from './list'

const store = { list }

export default store